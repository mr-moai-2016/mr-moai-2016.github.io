
var previewing_img_url = "";
var now_showing_idx = -1;

function changeObjBGColor( obj, color )
{
	if( obj.style && obj.style.backgroundColor ){
		obj.style.backgroundColor = '';
	} else {
		obj.style.backgroundColor = color;
	}
}
function findUrlList( query_img_url )
{
	for(var i=0;i<img_url_list.length;i++){
		if( query_img_url == img_url_list[ i ] ){
			return i;
		}
	}
	return -1;
}

/*
<script type="text/javascript">
//�ǂݍ��ݎ��̕\��
window_load();

//�E�B���h�E�T�C�Y�ύX���ɍX�V
window.onresize = window_load;

//�T�C�Y�̕\��
function window_load() {
	document.winsize.sw.value = window.innerWidth;
	document.winsize.sh.value = window.innerHeight;
}
</script>
*/


function Easter_showPreview( obj, img_url, max_width, max_height, preview_style )
{
	var preview_id = "upper_preview";

	if( preview_style == 'upper' ){
		preview_id = "upper_preview";
	} else if( preview_style == 'right' ){
		preview_id = "right_preview";
	} else {
		if( window.innerWidth < 1200 ){
			preview_id = "upper_preview";
		} else {
			preview_id = "right_preview";
		}
		if( typeof window.addEventListener == 'undefined' && typeof document.getElementsByClassName == 'undefined' ){
			// IE8lt
			preview_id = "upper_preview";
		} else if( !!document.uniqueID && document.documentMode <= 10 ){
			// IE10lt
			preview_id = "upper_preview";
		}
	}

	if( previewing_img_url == img_url ){
		document.getElementById(preview_id).innerHTML = "";
		previewing_img_url = "";
		now_showing_idx = -1;
		var ahref_previewables = document.getElementsByName("ahref_previewable");
		for(var i=0;i<ahref_previewables.length;i++){
			changeObjBGColor( ahref_previewables[i], '' );
		}
	} else {
		var img = new Image();
	
		// 640, 824 
		/***
		 * IE8�΍�:
		 * IE8�ȑO�ł̓L���b�V������摜�����[�h����ꍇ��onload�C�x���g���������Ȃ��Ƃ������ۂ�
		 * ���܂ɋN����(�����ł͂Ȃ��悤�ł���)
		 * ������������ɂ� img.src = img_url���O��onload�֐����`���Ă����Ƃ悢�Ƃ̂��Ƃł���.
		 * ���̂悤�ɂ���΃L���b�V������̃��[�h�ł����Ă�onload�C�x���g�𔭐������邱�Ƃ��ł���.
		 */
		img.onload = function(){
			if( img.width < max_width && img.height < max_height){
				document.getElementById(preview_id).innerHTML = ""
						+ "Original Size:" + img.width + "x" + img.height + " This preview is original size."
						+ "<br>"
						//+ "<div class=MstyComment>"
						+ "<a href=\"" + img_url + "\" target=_blank>"
						+ "<img src=\"" + img_url + "\" class=MstyImgPreview></a>";
						//+ "</div>";
			} else if( img.width >= max_width || img.height >= max_height ){
				var rate_x = max_width  / img.width;
				var rate_y = max_height / img.height;
				var mod_width  = max_width;
				var mod_height = max_height;
				if( rate_x < rate_y ){
					mod_width  = img.width  * rate_x;
					mod_height = img.height * rate_x;
				} else {
					mod_width  = img.width  * rate_y;
					mod_height = img.height * rate_y;
				}
				document.getElementById(preview_id).innerHTML = ""
						+ "Original Size:" + img.width + "x" + img.height + " max_width=" + max_width + " max_height=" + max_height + " This preview may be shrinked."
						+ "<br>"
						//+ "<div class=MstyComment>"
						+ "<a href=\"" + img_url + "\" target=_blank>"
						+ "<img src=\"" + img_url + "\" width=" + mod_width + " height=" + mod_height + "></a>";
						//+ "</div>";
			} else {
				var authentic_key = "";
				var cache_path = "";
				var rate_nx = Math.floor( max_width * 1000 /img.width );
				var rate_rx = rate_nx % 10;
				var rate_ny = Math.floor( max_height * 1000 /img.height );
				var rate_ry = rate_ny % 10;
				var rate_ix = ( rate_nx - rate_rx ) / 10;
				var rate_iy = ( rate_ny - rate_ry ) / 10;
				var rate_str = "";
				var rate_i = 0;
				var rate_r = 0.0;
				//var class_name = "MstyImgPreviewShrinkX";
				var class_name = "MstyImgPreviewShrinkXY";
				if( rate_ix > rate_iy ){
					class_name = "MstyImgPreviewShrinkY";
					//class_name = "MstyImgPreviewShrinkXY";
					rate_i = rate_iy;
					rate_r = rate_ry;
				} else {
					//class_name = "MstyImgPreviewShrinkX";
					class_name = "MstyImgPreviewShrinkXY";
					rate_i = rate_ix;
					rate_r = rate_rx;
				}
				if( rate_i < 80 ){
					rate_str = "<font color=#ff0000>" + rate_i + "." + rate_r + "</font>";
				} else {
					rate_str = rate_i + "." + rate_r;
				}
				document.getElementById(preview_id).innerHTML = ""
						+ "Original Size:" + img.width + "x" + img.height + " This preview may NOT be original size."
						+ "<a href=\"" + img_url + "\" target=_blank>" + " Original Image is Here." + "</a>"
						+ "<br>"
						//+ "<div class=MstyComment>"
						+ "<a href=\"" + img_url + "\" target=_blank>"
						+ "<img src=\"" + img_url + "\" width=100%></a>"
						//+ "</div>";
			}
			previewing_img_url = img_url;
			now_showing_idx = findUrlList( previewing_img_url );
		};
		img.onerror = function(){
			document.getElementById(preview_id).innerHTML = "<a href=\"" + img_url + "\" target=_blank>" + "Original Image" + "</a>"
					+ "<br>Image loading error.<br>"
			previewing_img_url = img_url;
			now_showing_idx = findUrlList( previewing_img_url );
		};
		var ahref_previewables = document.getElementsByName("ahref_previewable");
		for(var i=0;i<ahref_previewables.length;i++){
			changeObjBGColor( ahref_previewables[i], '' );
		}
		changeObjBGColor( obj, '#a0a0ff' );
	
		document.getElementById(preview_id).innerHTML = img_url + "<br>Now loading...<br>"
		img.src = img_url;
	}
}
function Easter_showNext( obj, max_width, max_height, preview_style )
{
	if( img_url_list.length ){
		var new_img_url = "";
		var show_idx = -1;
		if( previewing_img_url != "" ){
			show_idx = findUrlList( previewing_img_url );
			if( show_idx == img_url_list.length-1 ){
				show_idx = 0;
			} else {
				show_idx += 1;
			}
		} else {
			show_idx = 0;
		}
		new_img_url = img_url_list[ show_idx ];

		{
			var ahref_previewables = document.getElementsByName("ahref_previewable");
			Easter_showPreview( ahref_previewables[show_idx], new_img_url, max_width, max_height, preview_style );
			//document.getElementById("now_showing_path").innerHTML = new_img_url;
		}
	}

}
function Easter_showPrev( obj, max_width, max_height, preview_style )
{
	if( img_url_list.length ){
		var new_img_url = "";
		var show_idx = -1;
		if( previewing_img_url != "" ){
			show_idx = findUrlList( previewing_img_url );
			if( show_idx <= 0 ){
				show_idx = img_url_list.length-1;
			} else {
				show_idx -= 1;
			}
		} else {
			show_idx = img_url_list.length-1;
		}
		new_img_url = img_url_list[ show_idx ];

		{
			var ahref_previewables = document.getElementsByName("ahref_previewable");
			Easter_showPreview( ahref_previewables[show_idx], new_img_url, max_width, max_height, preview_style );
			//document.getElementById("now_showing_path").innerHTML = new_img_url;
		}
	}
}
function Easter_hidePreview( obj )
{
	Easter_showPreview( obj, previewing_img_url, 0, 0, 'right' );
	Easter_showPreview( obj, previewing_img_url, 0, 0, 'upper' );
}

function EasterModal_open() {
	var elem = document.getElementById("Easter_modal_img");
	elem.src = "/moai.png";
	document.getElementById('Easter_modal').classList.add('is-active');
}

function EasterModal_close() {
	document.getElementById('Easter_modal').classList.remove('is-active');
}
