/* 0-byte avoidance */
